import { Component, OnInit } from '@angular/core';
import axios from 'axios';

interface JobList {
  job: string;
  created: string;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  items: JobList[] | undefined;
  ngOnInit() {
    this.fetchItems();
  }
  fetchItems(): void {
    axios.get<JobList[]>('http://localhost:3000/api/list')
      .then(response => {
        this.items = response.data;
        console.log(this.items);
      })
      .catch(error => {
        console.log(error);
      });
  }
}