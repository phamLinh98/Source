import { Injectable } from '@angular/core';
import { Observable, from } from 'rxjs';
import { Pool, QueryResult } from 'pg';

@Injectable({
  providedIn: 'root'
})
export class ListServiceService {

  constructor(private pool: Pool) { }

  query(sql:string, params:any[] = []):Observable<QueryResult>
  {
    return from(this.pool.query(sql,params));
  }
  }
